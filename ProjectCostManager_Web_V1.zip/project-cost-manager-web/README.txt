PROJECT COST MANAGER - WEB V1
1. Upload index.html to a static hosting service such as GitHub Pages.
2. Open the resulting website on your Android phone.
3. Data is stored locally in the browser (localStorage).
4. No login/server is required for this V1.
